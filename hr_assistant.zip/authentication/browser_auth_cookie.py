"""Read, write, and remove the signed authentication browser cookie.

The cookie controller is asynchronous. A brand-new browser refresh mounts the
component once and waits for its first result. The implementation deliberately
avoids calling ``refresh()`` immediately after construction because that would
render the same keyed component twice in one Streamlit run and can raise a
component/session-state error.
"""

from time import monotonic

import streamlit as st

from config.settings import get_settings


AUTH_COOKIE_NAME = "ai_hr_signed_auth"
COOKIE_CONTROLLER_KEY = "ai_hr_auth_cookie_controller"
TRANSITION_STARTED_KEY = "_auth_cookie_transition_started"
TRANSITION_KIND_KEY = "_auth_cookie_transition_kind"


def _clean_cookie_value(value) -> str | None:
    """Return one bounded non-empty cookie value."""

    if not isinstance(value, str):
        return None

    cleaned = value.strip()

    if not cleaned or len(cleaned) > 4096:
        return None

    return cleaned


def request_auth_cookie() -> str | None:
    """Read the signed cookie sent with the current browser connection."""

    return _clean_cookie_value(
        st.context.cookies.get(AUTH_COOKIE_NAME)
    )


def _get_cookie_controller():
    """Load the browser-cookie component only when required."""

    try:
        from streamlit_cookies_controller import CookieController
    except ImportError as error:
        raise RuntimeError(
            "streamlit-cookies-controller is not installed. "
            "Run: python -m pip install -r requirements.txt"
        ) from error

    return CookieController(key=COOKIE_CONTROLLER_KEY)


def component_auth_cookie() -> str | None:
    """Read the cookie value returned by the mounted browser component.

    CookieController's constructor already performs its initial ``getAll``
    component call. Calling ``refresh()`` in the same run can duplicate the
    keyed component, so this function reads the constructor result directly.
    """

    controller = _get_cookie_controller()
    return _clean_cookie_value(
        controller.get(AUTH_COOKIE_NAME)
    )


def cookie_component_was_mounted() -> bool:
    """Return whether this Streamlit session already mounted the reader."""

    return COOKIE_CONTROLLER_KEY in st.session_state


def wait_for_initial_cookie_component() -> None:
    """Keep the login page hidden while the first cookie result arrives."""

    st.info("Restoring your secure session…")
    st.stop()


def _delayed_app_rerun(
    *,
    transition_kind: str,
    message: str,
    delay_seconds: float = 1.0,
) -> None:
    """Let a cookie component command reach the browser before rerunning."""

    if st.session_state.get(TRANSITION_KIND_KEY) != transition_kind:
        st.session_state[TRANSITION_KIND_KEY] = transition_kind
        st.session_state[TRANSITION_STARTED_KEY] = monotonic()

    st.info(message)

    @st.fragment(run_every="1s")
    def transition_timer() -> None:
        started_at = float(
            st.session_state.get(
                TRANSITION_STARTED_KEY,
                monotonic(),
            )
        )

        if monotonic() - started_at >= delay_seconds:
            st.session_state.pop(TRANSITION_STARTED_KEY, None)
            st.session_state.pop(TRANSITION_KIND_KEY, None)
            st.rerun(scope="app")

    transition_timer()
    st.stop()


def write_auth_cookie_and_continue(token: str) -> None:
    """Write the login cookie and continue to the authenticated portal."""

    settings = get_settings()
    controller = _get_cookie_controller()
    controller.set(
        AUTH_COOKIE_NAME,
        token,
        path="/",
        max_age=settings.auth_cookie_hours * 60 * 60,
        secure=settings.auth_cookie_secure,
        same_site="strict",
    )

    _delayed_app_rerun(
        transition_kind="login",
        message="Completing sign in…",
    )


def replace_auth_cookie_and_continue(token: str) -> None:
    """Replace the cookie after password change and continue."""

    settings = get_settings()
    controller = _get_cookie_controller()
    controller.set(
        AUTH_COOKIE_NAME,
        token,
        path="/",
        max_age=settings.auth_cookie_hours * 60 * 60,
        secure=settings.auth_cookie_secure,
        same_site="strict",
    )

    st.success("Password changed successfully.")
    _delayed_app_rerun(
        transition_kind="password_change",
        message="Opening your portal…",
    )


def remove_auth_cookie(*, wait_for_completion: bool) -> None:
    """Remove the signed browser cookie."""

    controller = _get_cookie_controller()
    settings = get_settings()

    try:
        controller.remove(
            AUTH_COOKIE_NAME,
            path="/",
            secure=settings.auth_cookie_secure,
            same_site="strict",
        )
    except KeyError:
        # The command is still sent even when the local component cache did
        # not contain the cookie name.
        pass

    if wait_for_completion:
        _delayed_app_rerun(
            transition_kind="logout",
            message="Signing out…",
        )
