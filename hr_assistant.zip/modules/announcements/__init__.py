"""Announcement feature helpers."""
