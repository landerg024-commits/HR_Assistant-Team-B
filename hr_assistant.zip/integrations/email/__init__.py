"""Email delivery adapters."""
